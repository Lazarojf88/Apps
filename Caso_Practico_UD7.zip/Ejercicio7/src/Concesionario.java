
public class Concesionario {

	public static void main(String[] args) {
		// TODO Apéndice de método generado automáticamente

        CocheKm0 cocheKm0 = new CocheKm0("1234ABC", "Rojo", "Seat Ibiza", 15000, 500);
        CocheNuevo cocheNuevo = new CocheNuevo("5678DEF", "Azul", "Toyota Corolla", 22000, 0, 24);
        CocheSegundaMano cocheSM = new CocheSegundaMano("9876ZYX", "Negro", "Ford Focus", 10000, 45000, "Luis Pérez");

        System.out.println(cocheKm0.toString());
        cocheKm0.alquilar();

        System.out.println(cocheNuevo.toString());
        cocheNuevo.vender();

        System.out.println(cocheSM.toString());
        cocheSM.vender();

        System.out.println("Coches en stock: " + Coche.getNumCochesStock());
    }
}
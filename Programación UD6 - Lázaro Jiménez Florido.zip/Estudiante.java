public class Estudiante {
    private String nombre;
    private int edad;
    private double notaMedia;

    // Constructor
    public Estudiante(String nombre, int edad, double notaMedia) {
        this.nombre = nombre;
        this.edad = edad;
        this.notaMedia = notaMedia;
    }

    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getNotaMedia() {
        return notaMedia;
    }

    public void setNotaMedia(double notaMedia) {
        this.notaMedia = notaMedia;
    }

    // Método toString para mostrar la información del estudiante
    @Override
    public String toString() {
    	System.out.println("------------------------------------------");
        return "Nombre: " + nombre + ", Edad: " + edad + ", Nota media: " + notaMedia;
    }
}

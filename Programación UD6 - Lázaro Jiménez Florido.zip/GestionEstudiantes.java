import java.util.ArrayList;
import java.util.Scanner;

public class GestionEstudiantes {
    private static Scanner scanner = new Scanner(System.in);

    // Lista de estudiantes usando ArrayList
    private static ArrayList<Estudiante> estudiantesArrayList = new ArrayList<>();
    
    // Array de estudiantes para gestionar con Array
    private static Estudiante[] estudiantesArray = new Estudiante[10]; // tamaño fijo de 10 estudiantes
    private static int numEstudiantesArray = 0; // Contador de estudiantes en el array

    // Método principal
    public static void main(String[] args) {
        while (true) {
        	System.out.println();
            System.out.println("Menú Principal:");
            System.out.println("1. Usar Array");
            System.out.println("2. Usar ArrayList");
            System.out.println("3. Salir");
            System.out.print("Elige una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine();  // Limpiar el buffer

            switch (opcion) {
                case 1:
                    gestionarArray();
                    break;
                case 2:
                    gestionarArrayList();
                    break;
                case 3:
                	System.out.println();
                    System.out.println("¡Hasta luego Mari Carmen!");
                    return;
                default:
                    System.out.println("Opción no válida. Intenta de nuevo.");
            }
        }
    }

    // Submenú Array
    public static void gestionarArray() {
        while (true) {
        	System.out.println();
            System.out.println("Submenú Array:");
            System.out.println("1. Agregar un estudiante al Array");
            System.out.println("2. Ver todos los estudiantes del Array");
            System.out.println("3. Buscar un estudiante por nombre");
            System.out.println("4. Volver al menú principal");
            System.out.print("Elige una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine();  // Limpiar el buffer

            switch (opcion) {
                case 1:
                    agregarEstudianteArray();
                    break;
                case 2:
                    verEstudiantesArray();
                    break;
                case 3:
                    buscarEstudianteArray();
                    break;
                case 4:
                    return;  // Volver al menú principal
                default:
                    System.out.println("Opción no válida. Intenta de nuevo.");
            }
        }
    }

    // Método para agregar un estudiante al array
    public static void agregarEstudianteArray() {
        if (numEstudiantesArray >= estudiantesArray.length) {
            System.out.println("No se pueden agregar más estudiantes, el array está lleno.");
        } else {
        	System.out.println();
            System.out.print("Introduce el nombre del estudiante: ");
            String nombre = scanner.nextLine();
            System.out.print("Introduce la edad del estudiante: ");
            int edad = scanner.nextInt();
            System.out.print("Introduce la nota media del estudiante: ");
            double notaMedia = scanner.nextDouble();
            scanner.nextLine();  // Limpiar el buffer

            estudiantesArray[numEstudiantesArray] = new Estudiante(nombre, edad, notaMedia);
            numEstudiantesArray++;
            System.out.println();
            System.out.println("¡Estudiante agregado correctamente!");
        }
    }

    // Método para ver todos los estudiantes en el array
    public static void verEstudiantesArray() {
        if (numEstudiantesArray == 0) {
        	System.out.println();
            System.out.println("No hay estudiantes registrados.");
        } else {
            for (int i = 0; i < numEstudiantesArray; i++) {
                System.out.println(estudiantesArray[i]);
            }
        }
    }

    // Método para buscar un estudiante por nombre en el array
    public static void buscarEstudianteArray() {
    	System.out.println();
        System.out.print("Introduce el nombre del estudiante a buscar: ");
        String nombre = scanner.nextLine();
        boolean encontrado = false;

        for (int i = 0; i < numEstudiantesArray; i++) {
            if (estudiantesArray[i].getNombre().equalsIgnoreCase(nombre)) {
                System.out.println("Estudiante encontrado: " + estudiantesArray[i]);
                encontrado = true;
                break;
            }
        }

        if (!encontrado) {
        	System.out.println();
            System.out.println("Estudiante no encontrado.");
        }
    }

    // Submenú ArrayList
    public static void gestionarArrayList() {
        while (true) {
        	System.out.println();
            System.out.println("Submenú ArrayList:");
            System.out.println("1. Agregar un estudiante");
            System.out.println("2. Ver todos los estudiantes");
            System.out.println("3. Eliminar un estudiante por nombre");
            System.out.println("4. Buscar un estudiante por nombre");
            System.out.println("5. Volver al menú principal");
            System.out.print("Elige una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine();  // Limpiar el buffer

            switch (opcion) {
                case 1:
                    agregarEstudianteArrayList();
                    break;
                case 2:
                    verEstudiantesArrayList();
                    break;
                case 3:
                    eliminarEstudianteArrayList();
                    break;
                case 4:
                    buscarEstudianteArrayList();
                    break;
                case 5:
                    return;  // Volver al menú principal
                default:
                    System.out.println("Opción no válida. Intenta de nuevo.");
            }
        }
    }

    // Método para agregar un estudiante a ArrayList
    public static void agregarEstudianteArrayList() {
        System.out.print("Introduce el nombre del estudiante: ");
        String nombre = scanner.nextLine();
        System.out.print("Introduce la edad del estudiante: ");
        int edad = scanner.nextInt();
        System.out.print("Introduce la nota media del estudiante: ");
        double notaMedia = scanner.nextDouble();
        scanner.nextLine();  // Limpiar el buffer

        estudiantesArrayList.add(new Estudiante(nombre, edad, notaMedia));
        System.out.println("¡Estudiante agregado correctamente!");
    }

    // Método para ver todos los estudiantes en ArrayList
    public static void verEstudiantesArrayList() {
        if (estudiantesArrayList.isEmpty()) {
            System.out.println("No hay estudiantes registrados.");
        } else {
            for (Estudiante estudiante : estudiantesArrayList) {
                System.out.println(estudiante);
            }
        }
    }

    // Método para eliminar un estudiante por nombre en ArrayList
    public static void eliminarEstudianteArrayList() {
        System.out.print("Introduce el nombre del estudiante a eliminar: ");
        String nombre = scanner.nextLine();
        boolean encontrado = false;

        for (Estudiante estudiante : estudiantesArrayList) {
            if (estudiante.getNombre().equalsIgnoreCase(nombre)) {
                estudiantesArrayList.remove(estudiante);
                encontrado = true;
                System.out.println();
                System.out.println("¡Estudiante eliminado!");
                break;
            }
        }

        if (!encontrado) {
        	System.out.println();
            System.out.println("¡Estudiante NO encontrado!");
        }
    }

    // Método para buscar un estudiante por nombre en ArrayList
    public static void buscarEstudianteArrayList() {
        System.out.print("Introduce el nombre del estudiante a buscar: ");
        String nombre = scanner.nextLine();
        boolean encontrado = false;

        for (Estudiante estudiante : estudiantesArrayList) {
            if (estudiante.getNombre().equalsIgnoreCase(nombre)) {
                System.out.println("Estudiante encontrado: " + estudiante);
                encontrado = true;
                break;
            }
        }

        if (!encontrado) {
            System.out.println("¡Estudiante NO encontrado!");
        }
    }
}
